<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php
    $this->page->generateCss();
    ?>


    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/styles.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/table.css">
    <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/logo.png">

    <title><?php echo $this->page->generateTitle(); ?></title>
</head>

<body id="body-pd">
    <div class="l-navbar" id="navbar">
        <nav class="navigate">
            <div>
                <div class="nav__brand">
                    <ion-icon name="menu-outline" class="nav__toggle" id="nav-toggle"></ion-icon>
                    <h2><?php echo $this->session->userdata("nama"); ?></h2>
                </div>
                <div class="nav__list">
                    <a href="<?php echo site_url('Welcome/menuUtama') ?>" class="nav__link ">
                        <ion-icon name="home-outline" class="nav__icon"></ion-icon>
                        <span class="nav__name">Dashboard</span>
                    </a>
                    <a href="<?php echo site_url('kriteria') ?>" class="nav__link">
                        <ion-icon name="chatbubbles-outline" class="nav__icon"></ion-icon>
                        <span class="nav__name">Data Kriteria & Bobot</span>
                    </a>

                    <div class="nav__link collapse">
                        <ion-icon name="folder-outline" class="nav__icon"></ion-icon>
                        <span class="nav__name">Data Sekolah</span>

                        <ion-icon name="chevron-down-outline" class="collapse__link"></ion-icon>

                        <ul class="collapse__menu">
                            <a href="<?php echo site_url('SekolahDasar') ?>" class="collapse__sublink">SD</a>
                            <a href="<?php echo site_url('SMP') ?>" class="collapse__sublink">SMP</a>
                            <a href="<?php echo site_url('SMA') ?>" class="collapse__sublink">SMA</a>
                        </ul>
                    </div>

                    <div class="nav__link collapse">
                        <ion-icon name="people-outline" class="nav__icon"></ion-icon>
                        <span class="nav__name">Rangking</span>

                        <ion-icon name="chevron-down-outline" class="collapse__link"></ion-icon>

                        <ul class="collapse__menu">
                            <a href="<?php echo site_url('rangking') ?>" class="collapse__sublink">SD</a>
                            <a href="<?php echo site_url('RangkingSMP') ?>" class="collapse__sublink">SMP</a>
                            <a href="<?php echo site_url('RangkingSMA') ?>" class="collapse__sublink">SMA</a>
                        </ul>
                    </div>
                    <a href="#" class="nav__link">
                        <ion-icon name="settings-outline" class="nav__icon"></ion-icon>
                        <span class="nav__name">Kuisioner</span>
                    </a>
                </div>
            </div>

            <a href="<?php echo base_url('login/logout'); ?>" class="nav__link">
                <ion-icon name="log-out-outline" class="nav__icon"></ion-icon>
                <span class="nav__name">Log Out</span>
            </a>
        </nav>
    </div>

    <div class="container">
        <?php $this->load->view($view, $data); ?>
    </div>

    <script>
        var base_url = "<?php echo site_url(); ?>";
    </script>
    <?php
    $this->page->generateJs();
    ?>

    <!-- ===== IONICONS ===== -->
    <script src="https://unpkg.com/ionicons@5.1.2/dist/ionicons.js"></script>

    <!-- ===== MAIN JS ===== -->
    <script src="<?php echo base_url(); ?>assets/js/main.js"></script>

    <script src="<?php echo base_url(); ?>assets/js/sekolah.js"></script>

</html>