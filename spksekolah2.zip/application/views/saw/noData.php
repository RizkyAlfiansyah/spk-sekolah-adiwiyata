<h1>
    <div class="alert alert-danger" role="alert">
        Data Sekolah kosong, Harap mengisi data sekolah untuk menghitung rangking !
    </div>
</h1>